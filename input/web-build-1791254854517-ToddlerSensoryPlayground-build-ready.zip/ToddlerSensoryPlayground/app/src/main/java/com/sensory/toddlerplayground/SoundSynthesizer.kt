package com.sensory.toddlerplayground

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class SoundSynthesizer {

    private val chimeFrequencies = floatArrayOf(
        523.25f, 587.33f, 659.25f, 783.99f, 880.00f, 1046.50f, 1174.66f, 1318.51f
    )

    private val sampleRate = 44100
    private val durationSeconds = 0.45f
    private val totalSamples = (sampleRate * durationSeconds).toInt()

    fun playPopChime() {
        val freq = chimeFrequencies[Random.nextInt(chimeFrequencies.size)]
        playTone(freq)
    }

    fun playSparkle() {
        playTone(1567.98f)
    }

    private fun playTone(frequency: Float) {
        Thread {
            try {
                val buffer = ShortArray(totalSamples)
                val decayRate = 7.0f

                for (i in 0 until totalSamples) {
                    val t = i.toFloat() / sampleRate
                    val envelope = exp(-decayRate * t)
                    val sample = (sin(2.0 * PI * frequency * t) * 0.75 +
                                  sin(2.0 * PI * (frequency * 2.76) * t) * 0.25) * envelope

                    buffer[i] = (sample * Short.MAX_VALUE * 0.6f).toInt().coerceIn(
                        Short.MIN_VALUE.toInt(),
                        Short.MAX_VALUE.toInt()
                    ).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()

                Thread.sleep((durationSeconds * 1000).toLong())
                audioTrack.release()
            } catch (_: Exception) {}
        }.start()
    }
}