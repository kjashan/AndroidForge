package com.sensory.toddlerplayground

import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class SensoryType {
    CIRCLE, BUBBLE, STAR, FISH, BUTTERFLY, FIREFLY
}

val ToddlerPalette = listOf(
    Color(0xFFFF6EC7),
    Color(0xFFFFD93D),
    Color(0xFF6BCB77),
    Color(0xFF4D96FF),
    Color(0xFFFF9F45),
    Color(0xFFC780FA),
    Color(0xFF54E346),
    Color(0xFF00F5D4)
)

class SensoryObject(
    val id: Long = Random.nextLong(),
    var type: SensoryType = SensoryType.entries.random(),
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = (Random.nextFloat() - 0.5f) * 70f,
    var vy: Float = (Random.nextFloat() - 0.5f) * 70f,
    var baseRadius: Float = Random.nextFloat() * 25f + 35f,
    var color: Color = ToddlerPalette.random(),
    var wobblePhase: Float = Random.nextFloat() * 100f,
    var isBursting: Boolean = false,
    var burstProgress: Float = 0f,
    var scale: Float = 1f,
    var glowIntensity: Float = 1f
) {
    fun update(dt: Float, screenWidth: Float, screenHeight: Float) {
        if (isBursting) {
            burstProgress += dt * 4.0f
            scale += dt * 2.5f
            glowIntensity += dt * 4.0f
            return
        }

        wobblePhase += dt * 1.5f
        val wobbleX = sin(wobblePhase) * 15f * dt
        val wobbleY = cos(wobblePhase * 0.8f) * 15f * dt

        x += (vx * dt) + wobbleX
        y += (vy * dt) + wobbleY

        val pad = baseRadius
        if (x < pad) { x = pad; vx = -vx }
        if (x > screenWidth - pad) { x = screenWidth - pad; vx = -vx }
        if (y < pad) { y = pad; vy = -vy }
        if (y > screenHeight - pad) { y = screenHeight - pad; vy = -vy }
    }
}

class BurstParticle(
    var x: Float,
    var y: Float,
    var color: Color,
    angle: Float = Random.nextFloat() * (2 * Math.PI.toFloat()),
    speed: Float = Random.nextFloat() * 250f + 100f
) {
    var vx: Float = cos(angle) * speed
    var vy: Float = sin(angle) * speed
    var life: Float = 1f
    var radius: Float = Random.nextFloat() * 8f + 4f

    fun update(dt: Float): Boolean {
        x += vx * dt
        y += vy * dt
        life -= dt * 2.0f
        return life > 0f
    }
}

class ScreenRipple(
    val x: Float,
    val y: Float,
    val color: Color,
    var radius: Float = 10f,
    var alpha: Float = 0.8f
) {
    fun update(dt: Float): Boolean {
        radius += dt * 350f
        alpha -= dt * 1.8f
        return alpha > 0f
    }
}