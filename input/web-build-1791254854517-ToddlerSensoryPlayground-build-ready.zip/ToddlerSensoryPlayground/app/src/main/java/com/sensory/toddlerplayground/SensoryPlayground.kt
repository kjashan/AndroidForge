package com.sensory.toddlerplayground

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlin.math.*
import kotlin.random.Random

@Composable
fun SensoryPlayground() {
    val context = LocalContext.current
    val vibrator = remember {
        ContextCompat.getSystemService(context, Vibrator::class.java)
    }
    val soundSynthesizer = remember { SoundSynthesizer() }

    val objects = remember { mutableStateListOf<SensoryObject>() }
    val particles = remember { mutableStateListOf<BurstParticle>() }
    val ripples = remember { mutableStateListOf<ScreenRipple>() }

    var screenSize by remember { mutableStateOf(Size.Zero) }

    fun triggerHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(30)
            }
        } catch (_: Exception) {}
    }

    fun spawnNewObject(w: Float, h: Float): SensoryObject {
        val pad = 80f
        return SensoryObject(
            x = Random.nextFloat() * (w - pad * 2) + pad,
            y = Random.nextFloat() * (h - pad * 2) + pad
        )
    }

    LaunchedEffect(Unit) {
        var lastTimeNanos = 0L
        while (true) {
            withFrameNanos { frameTimeNanos ->
                if (lastTimeNanos != 0L) {
                    val dt = ((frameTimeNanos - lastTimeNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)

                    if (screenSize.width > 0 && screenSize.height > 0) {
                        while (objects.size < 13) {
                            objects.add(spawnNewObject(screenSize.width, screenSize.height))
                        }

                        val iterator = objects.iterator()
                        val toAdd = mutableListOf<SensoryObject>()
                        while (iterator.hasNext()) {
                            val obj = iterator.next()
                            obj.update(dt, screenSize.width, screenSize.height)
                            if (obj.isBursting && obj.burstProgress >= 1f) {
                                iterator.remove()
                                toAdd.add(spawnNewObject(screenSize.width, screenSize.height))
                            }
                        }
                        objects.addAll(toAdd)

                        particles.removeAll { !it.update(dt) }
                        ripples.removeAll { !it.update(dt) }
                    }
                }
                lastTimeNanos = frameTimeNanos
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { tapOffset ->
                    var hit = false

                    for (obj in objects.asReversed()) {
                        if (obj.isBursting) continue
                        val dx = tapOffset.x - obj.x
                        val dy = tapOffset.y - obj.y
                        val dist = sqrt(dx * dx + dy * dy)
                        val touchRadius = obj.baseRadius + 45f

                        if (dist <= touchRadius) {
                            hit = true
                            obj.isBursting = true

                            soundSynthesizer.playPopChime()
                            triggerHaptic()

                            repeat(16) {
                                particles.add(
                                    BurstParticle(
                                        x = obj.x,
                                        y = obj.y,
                                        color = obj.color
                                    )
                                )
                            }
                            break
                        }
                    }

                    if (!hit) {
                        soundSynthesizer.playSparkle()
                        triggerHaptic()
                        ripples.add(ScreenRipple(tapOffset.x, tapOffset.y, ToddlerPalette.random()))
                        repeat(6) {
                            particles.add(
                                BurstParticle(
                                    x = tapOffset.x,
                                    y = tapOffset.y,
                                    color = ToddlerPalette.random(),
                                    speed = Random.nextFloat() * 100f + 40f
                                )
                            )
                        }
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            screenSize = size

            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1E1035),
                        Color(0xFF0F0B1E),
                        Color(0xFF05030A)
                    ),
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = size.maxDimension * 0.85f
                )
            )

            for (ripple in ripples) {
                drawCircle(
                    color = ripple.color.copy(alpha = ripple.alpha.coerceIn(0f, 1f)),
                    radius = ripple.radius,
                    center = Offset(ripple.x, ripple.y),
                    style = Stroke(width = 6f)
                )
            }

            for (obj in objects) {
                val alpha = if (obj.isBursting) (1f - obj.burstProgress).coerceIn(0f, 1f) else 1f
                val currentRadius = obj.baseRadius * obj.scale

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            obj.color.copy(alpha = 0.45f * alpha * obj.glowIntensity),
                            obj.color.copy(alpha = 0.15f * alpha),
                            Color.Transparent
                        ),
                        center = Offset(obj.x, obj.y),
                        radius = currentRadius * 2.2f
                    ),
                    center = Offset(obj.x, obj.y),
                    radius = currentRadius * 2.2f
                )

                when (obj.type) {
                    SensoryType.CIRCLE -> drawGlowCircle(obj, currentRadius, alpha)
                    SensoryType.BUBBLE -> drawBubble(obj, currentRadius, alpha)
                    SensoryType.STAR -> drawStar(obj, currentRadius, alpha)
                    SensoryType.FISH -> drawFish(obj, currentRadius, alpha)
                    SensoryType.BUTTERFLY -> drawButterfly(obj, currentRadius, alpha)
                    SensoryType.FIREFLY -> drawFirefly(obj, currentRadius, alpha)
                }
            }

            for (particle in particles) {
                drawCircle(
                    color = particle.color.copy(alpha = particle.life.coerceIn(0f, 1f)),
                    radius = particle.radius * particle.life,
                    center = Offset(particle.x, particle.y)
                )
            }
        }
    }
}

private fun DrawScope.drawGlowCircle(obj: SensoryObject, radius: Float, alpha: Float) {
    drawCircle(
        color = obj.color.copy(alpha = alpha),
        radius = radius,
        center = Offset(obj.x, obj.y)
    )
    drawCircle(
        color = Color.White.copy(alpha = 0.7f * alpha),
        radius = radius * 0.4f,
        center = Offset(obj.x - radius * 0.25f, obj.y - radius * 0.25f)
    )
}

private fun DrawScope.drawBubble(obj: SensoryObject, radius: Float, alpha: Float) {
    drawCircle(
        color = obj.color.copy(alpha = 0.35f * alpha),
        radius = radius,
        center = Offset(obj.x, obj.y)
    )
    drawCircle(
        color = Color.White.copy(alpha = 0.8f * alpha),
        radius = radius,
        center = Offset(obj.x, obj.y),
        style = Stroke(width = 4f)
    )
    drawCircle(
        color = Color.White.copy(alpha = 0.9f * alpha),
        radius = radius * 0.22f,
        center = Offset(obj.x - radius * 0.35f, obj.y - radius * 0.35f)
    )
}

private fun DrawScope.drawStar(obj: SensoryObject, radius: Float, alpha: Float) {
    val path = Path()
    val points = 5
    val innerRadius = radius * 0.45f
    val center = Offset(obj.x, obj.y)
    val rotationAngle = (obj.wobblePhase * 30f) % 360f

    rotate(rotationAngle, pivot = center) {
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) radius else innerRadius
            val angle = i * Math.PI / points - (Math.PI / 2.0)
            val px = center.x + (r * cos(angle)).toFloat()
            val py = center.y + (r * sin(angle)).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        drawPath(path = path, color = obj.color.copy(alpha = alpha), style = Fill)
    }
}

private fun DrawScope.drawFish(obj: SensoryObject, radius: Float, alpha: Float) {
    val movingRight = obj.vx >= 0
    val angle = if (movingRight) 0f else 180f
    val center = Offset(obj.x, obj.y)

    rotate(degrees = angle, pivot = center) {
        val fishPath = Path().apply {
            moveTo(center.x - radius, center.y)
            quadraticTo(center.x, center.y - radius * 0.6f, center.x + radius * 0.8f, center.y)
            quadraticTo(center.x, center.y + radius * 0.6f, center.x - radius, center.y)

            val wag = sin(obj.wobblePhase * 4f) * (radius * 0.3f)
            moveTo(center.x - radius, center.y)
            lineTo(center.x - radius * 1.5f, center.y - radius * 0.5f + wag)
            lineTo(center.x - radius * 1.5f, center.y + radius * 0.5f + wag)
            close()
        }
        drawPath(fishPath, color = obj.color.copy(alpha = alpha))

        drawCircle(
            color = Color.White.copy(alpha = alpha),
            radius = radius * 0.18f,
            center = Offset(center.x + radius * 0.45f, center.y - radius * 0.15f)
        )
        drawCircle(
            color = Color.Black.copy(alpha = alpha),
            radius = radius * 0.08f,
            center = Offset(center.x + radius * 0.5f, center.y - radius * 0.15f)
        )
    }
}

private fun DrawScope.drawButterfly(obj: SensoryObject, radius: Float, alpha: Float) {
    val center = Offset(obj.x, obj.y)
    val wingFlap = abs(sin(obj.wobblePhase * 3.5f)) * 0.6f + 0.4f

    scale(scaleX = wingFlap, scaleY = 1f, pivot = center) {
        drawOval(
            color = obj.color.copy(alpha = 0.85f * alpha),
            topLeft = Offset(center.x - radius * 1.2f, center.y - radius * 0.8f),
            size = Size(radius * 1.1f, radius * 1.6f)
        )
        drawOval(
            color = obj.color.copy(alpha = 0.85f * alpha),
            topLeft = Offset(center.x + radius * 0.1f, center.y - radius * 0.8f),
            size = Size(radius * 1.1f, radius * 1.6f)
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.9f * alpha),
            topLeft = Offset(center.x - radius * 0.1f, center.y - radius * 0.7f),
            size = Size(radius * 0.2f, radius * 1.4f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius * 0.1f)
        )
    }
}

private fun DrawScope.drawFirefly(obj: SensoryObject, radius: Float, alpha: Float) {
    val pulse = (sin(obj.wobblePhase * 3f) + 1f) * 0.5f
    val glowRadius = radius * (1.2f + pulse * 0.8f)

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.Yellow.copy(alpha = (0.7f + 0.3f * pulse) * alpha),
                obj.color.copy(alpha = 0.3f * alpha),
                Color.Transparent
            ),
            center = Offset(obj.x, obj.y),
            radius = glowRadius
        ),
        radius = glowRadius,
        center = Offset(obj.x, obj.y)
    )

    drawCircle(
        color = Color.White.copy(alpha = alpha),
        radius = radius * 0.35f,
        center = Offset(obj.x, obj.y)
    )
}